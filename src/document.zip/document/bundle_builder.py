
"""Merge deterministic process data with LLM-generated descriptions."""

from __future__ import annotations

from procedure.models import ProcedureModel

from .loader import GeneratedProcedure
from .models import (
    DocumentActor,
    DocumentBranch,
    DocumentBundle,
    DocumentBusinessDocument,
    DocumentBusinessRule,
    DocumentMetadata,
    DocumentNote,
    DocumentOperation,
    DocumentOperationKind,
    DocumentValidationSummary,
    ProcedureDocumentData,
    SpecificationDocumentData,
)


class DocumentBundleBuildError(ValueError):
    """Raised when the deterministic and generated models are inconsistent."""


class DocumentBundleBuilder:
    """Build the shared document model."""

    def build(
        self,
        procedure: ProcedureModel,
        generated: GeneratedProcedure,
    ) -> DocumentBundle:
        if procedure.metadata.process_id != generated.process_id:
            raise DocumentBundleBuildError(
                "The ProcedureModel and generated procedure use "
                "different process IDs."
            )

        generated_by_id = {
            operation.bpmn_element_id: operation
            for operation in generated.operations
        }

        deterministic_ids = {
            operation.bpmn_element_id
            for operation in procedure.operations
        }

        generated_ids = set(generated_by_id)

        missing_ids = deterministic_ids - generated_ids
        extra_ids = generated_ids - deterministic_ids

        if missing_ids:
            raise DocumentBundleBuildError(
                "Generated descriptions are missing for: "
                + ", ".join(sorted(missing_ids))
            )

        if extra_ids:
            raise DocumentBundleBuildError(
                "Generated descriptions contain unknown operations: "
                + ", ".join(sorted(extra_ids))
            )

        actors = self._build_actors(procedure)
        documents = self._build_documents(procedure)
        operations = self._build_operations(
            procedure=procedure,
            generated_by_id=generated_by_id,
        )

        business_rules = self._build_business_rules(
            operations=operations,
        )

        subprocess_ids = [
            operation.bpmn_element_id
            for operation in operations
            if operation.element_kind
            == DocumentOperationKind.SUBPROCESS
        ]

        business_event_ids = [
            operation.bpmn_element_id
            for operation in operations
            if operation.element_kind
            == DocumentOperationKind.BUSINESS_EVENT
        ]

        decision_gateway_ids = sorted(
            {
                branch.gateway_id
                for operation in operations
                for branch in operation.branches
            }
        )

        metadata = DocumentMetadata(
            process_id=procedure.metadata.process_id,
            title=generated.title,
            source_bpmn_path=procedure.metadata.source_path,
        )

        validation = DocumentValidationSummary(
            parser_is_valid=procedure.validation.is_valid,
            parser_error_count=procedure.validation.error_count,
            parser_warning_count=procedure.validation.warning_count,
            parser_issue_codes=procedure.validation.issue_codes,
            generation_warnings=generated.generation_warnings,
        )

        procedure_data = ProcedureDocumentData(
            purpose=(
                f"Cette procédure décrit les opérations du processus "
                f"« {generated.title} »."
            ),
            operations=operations,
            documents=documents,
            business_rules=business_rules,
        )

        specification_data = SpecificationDocumentData(
            actors=actors,
            operations=operations,
            documents=documents,
            subprocess_operation_ids=subprocess_ids,
            business_event_operation_ids=business_event_ids,
            decision_gateway_ids=decision_gateway_ids,
            unresolved_points=self._build_unresolved_points(
                operations=operations,
                validation=validation,
            ),
        )

        return DocumentBundle(
            metadata=metadata,
            actors=actors,
            documents=documents,
            operations=operations,
            validation=validation,
            procedure=procedure_data,
            specification=specification_data,
        )

    @staticmethod
    def _build_actors(
        procedure: ProcedureModel,
    ) -> list[DocumentActor]:
        operation_ids_by_actor: dict[str, list[str]] = {}

        for operation in procedure.operations:
            if not operation.actor_id:
                continue

            operation_ids_by_actor.setdefault(
                operation.actor_id,
                [],
            ).append(operation.bpmn_element_id)

        return [
            DocumentActor(
                id=actor.id,
                name=actor.name,
                source_type=actor.source_type,
                operation_ids=operation_ids_by_actor.get(
                    actor.id,
                    [],
                ),
            )
            for actor in procedure.actors
        ]

    @staticmethod
    def _build_documents(
        procedure: ProcedureModel,
    ) -> list[DocumentBusinessDocument]:
        return [
            DocumentBusinessDocument(
                id=document.id,
                name=document.name,
                source_type=document.source_type,
                produced_by_operation_ids=(
                    document.produced_by_operation_ids
                ),
                consumed_by_operation_ids=(
                    document.consumed_by_operation_ids
                ),
            )
            for document in procedure.documents
        ]

    @staticmethod
    def _build_operations(
        procedure: ProcedureModel,
        generated_by_id: dict,
    ) -> list[DocumentOperation]:
        result: list[DocumentOperation] = []

        operation_name_by_id = {
            operation.bpmn_element_id: operation.raw_name
            for operation in procedure.operations
        }

        document_by_id = {
            document.id: document
            for document in procedure.documents
        }

        note_by_id = {
            note.id: note
            for note in procedure.notes
        }

        for source in procedure.operations:
            generated = generated_by_id[source.bpmn_element_id]

            incorporated_note_ids = set(
                generated.incorporated_note_ids
            )

            source_notes = [
                note_by_id[note_id]
                for note_id in source.note_ids
                if note_id in note_by_id
            ]

            notes = [
                DocumentNote(
                    id=note.id,
                    text=note.text,
                    incorporated_in_description=(
                        note.id in incorporated_note_ids
                    ),
                )
                for note in source_notes
            ]

            input_document_names = [
                document_by_id[document_id].name
                for document_id in source.input_document_ids
                if document_id in document_by_id
            ]

            output_document_names = [
                document_by_id[document_id].name
                for document_id in source.output_document_ids
                if document_id in document_by_id
            ]

            branches = [
                DocumentBranch(
                    gateway_id=branch.gateway_id,
                    gateway_name=branch.gateway_name,
                    label=branch.label,
                    condition=branch.condition,
                    is_default=branch.is_default,
                    target_operation_id=branch.target_element_id,
                    target_operation_name=operation_name_by_id.get(
                        branch.target_element_id
                    ),
                )
                for branch in source.branches
            ]

            result.append(
                DocumentOperation(
                    number=source.number,
                    bpmn_element_id=source.bpmn_element_id,
                    raw_name=source.raw_name,
                    description=generated.description,
                    actor_id=(
                        None
                        if source.source_type == "serviceTask"
                        else source.actor_id
                    ),
                    actor_name=(
                        None
                        if source.source_type == "serviceTask"
                        else source.actor_name
                    ),
                    element_kind=DocumentOperationKind(
                        source.element_kind.value
                    ),
                    source_type=source.source_type,
                    previous_operation_ids=source.previous_operation_ids,
                    next_operation_ids=source.next_operation_ids,
                    input_document_names=input_document_names,
                    output_document_names=output_document_names,
                    notes=notes,
                    branches=branches,
                    confidence=generated.confidence,
                    requires_validation=generated.requires_validation,
                    warnings=generated.warnings,
                )
            )

        return result

    @staticmethod
    def _normalize_business_rule_text(
        text: str,
    ) -> str:
        """Clean BPMN annotation text without changing its meaning."""

        normalized = " ".join(
            text.replace(
                "\n",
                " ",
            ).split()
        ).strip()

        normalized = normalized.rstrip(
            " ,.;:"
        )

        if not normalized:
            return ""

        normalized = (
            normalized[0].upper()
            + normalized[1:]
        )

        return normalized + "."

    @staticmethod
    def _build_business_rules(
        operations: list[DocumentOperation],
    ) -> list[DocumentBusinessRule]:
        """
        Create one business rule for every BPMN annotation.

        All original notes are preserved, including notes already incorporated
        into the generated operation description.
        """

        rules: list[DocumentBusinessRule] = []
        seen_note_ids: set[str] = set()

        for operation in operations:
            for note in operation.notes:
                note_text = note.text.strip()

                if not note_text:
                    continue

                if note.id in seen_note_ids:
                    continue

                seen_note_ids.add(
                    note.id
                )

                normalized_text = (
                    DocumentBundleBuilder
                    ._normalize_business_rule_text(
                        note_text
                    )
                )

                if not normalized_text:
                    continue

                rules.append(
                    DocumentBusinessRule(
                        operation_number=operation.number,
                        text=normalized_text,
                        source_note_id=note.id,
                    )
                )

        return rules

    @staticmethod
    def _build_unresolved_points(
        operations: list[DocumentOperation],
        validation: DocumentValidationSummary,
    ) -> list[str]:
        unresolved: list[str] = []

        for operation in operations:
            if operation.requires_validation:
                unresolved.append(
                    (
                        f"Opération {operation.number} "
                        f"« {operation.raw_name} » : "
                        + (
                            "; ".join(operation.warnings)
                            if operation.warnings
                            else "validation manuelle requise"
                        )
                    )
                )

        unresolved.extend(validation.generation_warnings)

        return unresolved

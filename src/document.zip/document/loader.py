"""Load and validate the LLM-generated procedure JSON."""

from __future__ import annotations

import json
from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field, ValidationError


class GeneratedBaseModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class GeneratedAssociatedNote(GeneratedBaseModel):
    id: str
    text: str


class GeneratedOperation(GeneratedBaseModel):
    operation_number: int
    bpmn_element_id: str
    description: str

    input_document_names: list[str] = Field(default_factory=list)
    output_document_names: list[str] = Field(default_factory=list)

    associated_notes: list[GeneratedAssociatedNote] = Field(
        default_factory=list
    )
    incorporated_note_ids: list[str] = Field(default_factory=list)

    confidence: float = Field(ge=0.0, le=1.0)
    requires_validation: bool = False
    warnings: list[str] = Field(default_factory=list)


class GeneratedProcedure(GeneratedBaseModel):
    process_id: str
    title: str
    operation_count: int

    operations: list[GeneratedOperation] = Field(default_factory=list)
    generation_warnings: list[str] = Field(default_factory=list)


class GeneratedProcedureLoadError(ValueError):
    """Raised when generated procedure JSON cannot be loaded."""


def load_generated_procedure(
    path: str | Path,
) -> GeneratedProcedure:
    """Load and validate the Qwen-generated procedure."""

    input_path = Path(path)

    if not input_path.exists():
        raise FileNotFoundError(
            f"Generated procedure file not found: {input_path}"
        )

    try:
        raw_data = json.loads(
            input_path.read_text(encoding="utf-8")
        )
    except json.JSONDecodeError as exc:
        raise GeneratedProcedureLoadError(
            f"Invalid generated procedure JSON: {exc}"
        ) from exc

    try:
        procedure = GeneratedProcedure.model_validate(raw_data)
    except ValidationError as exc:
        raise GeneratedProcedureLoadError(
            f"Generated procedure does not match the expected schema: {exc}"
        ) from exc

    if procedure.operation_count != len(procedure.operations):
        raise GeneratedProcedureLoadError(
            "operation_count does not match the number of generated operations."
        )

    operation_ids = [
        operation.bpmn_element_id
        for operation in procedure.operations
    ]

    if len(operation_ids) != len(set(operation_ids)):
        raise GeneratedProcedureLoadError(
            "Duplicate BPMN operation IDs were found."
        )

    return procedure
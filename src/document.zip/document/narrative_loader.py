"""Load and validate a generated process narrative."""

from __future__ import annotations

import json
from pathlib import Path

from .narrative_models import GeneratedNarrative


class NarrativeLoadError(ValueError):
    """Raised when a generated narrative cannot be loaded."""


def load_generated_narrative(
    path: str | Path,
) -> GeneratedNarrative:
    """Load a generated narrative JSON file."""

    source_path = Path(path)

    if not source_path.exists():
        raise FileNotFoundError(
            f"Generated narrative not found: {source_path}"
        )

    try:
        raw_data = json.loads(
            source_path.read_text(
                encoding="utf-8"
            )
        )

        narrative = GeneratedNarrative.model_validate(
            raw_data
        )

    except (
        json.JSONDecodeError,
        ValueError,
    ) as exc:
        raise NarrativeLoadError(
            f"Invalid generated narrative: {exc}"
        ) from exc

    cleaned_paragraphs = [
        " ".join(
            paragraph.split()
        ).strip()
        for paragraph in narrative.paragraphs
        if paragraph.strip()
    ]

    if not cleaned_paragraphs:
        raise NarrativeLoadError(
            "The generated narrative contains no usable paragraphs."
        )

    return narrative.model_copy(
        update={
            "paragraphs": cleaned_paragraphs,
        }
    )